# Products Element

Allows you to add products to your page.

![](https://transvelo.github.io/docs/mybag/images/vc-products-element-setting.png)

## Settings

| Field | Type | Description | Default
| -- | -- | -- | -- |
| **Title** | Text |  Enter title. | 2015 Collection
| **Pre Title** | Text |  Enter Pre Title | Now Available
| **Product Content** | Select |  Choose Product Content | date
| **Extra Class** | Text | Enter Extra Class Name |

## Sample Output

![](https://transvelo.github.io/docs/mybag/images/vc-mybag-product-element-output.png)
