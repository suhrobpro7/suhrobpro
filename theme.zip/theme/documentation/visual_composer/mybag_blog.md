# MyBag Blog

Allows you to add blog post on your page.

![](https://transvelo.github.io/docs/mybag/images/vc-mybag-blog-setting.png)

## Settings

| Field | Type | Description | Default
| -- | -- | -- | -- |
| **Enter title** | Text |  Enter title. | Latest From Blog
| **Number of Blogs to display** | Text |  Set the Number of Brands to be displayed on the page | 2
| **Order by** | Text |  Set the order of the carousel to be Displayed | date
| **Order** | Text | Set the Carousel in Ascending or Descending Order. | DESC

## Sample Output

![](https://transvelo.github.io/docs/mybag/images/vc-mybag-blog-output.png)
