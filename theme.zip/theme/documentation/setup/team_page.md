# Team Page

Team Page of Unicase is built using **Visual Composer**.It has one rows. The **Visual Composer** Backend editor of the page look like this

![](https://transvelo.github.io/unicase/docs/images/team.png)

### Row 1
---

* It has four columns in the ration of (3/12 : 3/12 : 3/12 : 3/12).
* All the columns have Team Member Setting.
* Here is a sample of Team Member setting.

![](https://transvelo.github.io/unicase/docs/images/team-member-setting.png)


