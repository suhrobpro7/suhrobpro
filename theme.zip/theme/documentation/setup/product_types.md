# Product Types

When adding products to your store, they will be assigned specific product data. Here are the four default types that come with **WooCommerce**.

* [**Simple Product**](simple_product.md)
* [**Grouped Product**](grouped_product.md)
* [**External/affiliate Product**](externalaffiliate_product.md)
* [**Variable Product**](variable_product.md)
