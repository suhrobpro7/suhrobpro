# External/affiliate Product

## Description

A product your will add to your store but buyers will be sent to another site to purchase it. Affiliates work well or products you may make a commission on.

![](https://transvelo.github.io/unicase/docs/images/external-product-type.png)

## Sample Output

![](https://transvelo.github.io/unicase/docs/images/external-product-type-output.png)
