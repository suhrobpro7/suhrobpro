# Simple Product

## Description

This is a single physical product that has no variations.

![](https://transvelo.github.io/unicase/docs/images/simple-product-type.png)

## Sample Output

![](https://transvelo.github.io/unicase/docs/images/simple-product-type-output.png)
