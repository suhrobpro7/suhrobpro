# Grouped Product

## Description

A collection of products that are related but can be purchased separately. An example would be different models of the iMac from Apple.

![](https://transvelo.github.io/unicase/docs/images/grouped-product-type.png)

## Sample Output

![](https://transvelo.github.io/unicase/docs/images/grouped-product-type-output.png)
