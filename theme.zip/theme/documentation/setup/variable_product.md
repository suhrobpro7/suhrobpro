# Variable Product

## Description

Some products will have different variations and multiple images. For example a t-shirt, that comes in different sizes and colors, with different prices.

![](https://transvelo.github.io/unicase/docs/images/variable-product-type.png)

## Sample Output

![](https://transvelo.github.io/unicase/docs/images/variable-product-type-output.png)
