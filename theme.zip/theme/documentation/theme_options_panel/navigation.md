# Navigation

## Navigation Options


#### Primary Navigation

* Set a Dropdown Style for Primary Navigation.
* Set a Dropdown Trigger for Primary Navigation.
* Set a Dropdown Animation for Primary Navigation.
* Enable / Disable the Show Dropdown Indicator.

![](https://transvelo.github.io/docs/mybag/images/theme-options-navigation.png)




