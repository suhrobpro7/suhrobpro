# Layout

## Layout Options

* Choose the Layout as you wish.

![](https://transvelo.github.io/docs/mybag/images/theme-options-layout.png)
